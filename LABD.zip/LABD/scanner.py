from tokens import *
from stringFunctions import *
from DFADirect import *
from ExpressionTree import *
from regEx import *

delim = "( |\t|\n)"
ws = "( |\t|\n)+"
letter = "(A-Z|a-z)"
digit = "(0-9)"
ids = "(A-Z|a-z)((A-Z|a-z)|(0-9))∗"

tokenRules = {'( |\\t|\\n)+': 'N', 'id': 'ID', "'+'": 'PLUS', "'*'": 'TIMES', "'('": 'LPAREN', "')'": 'RPAREN'}

tokensExp = "( |\t|\n)+|id|'+'|'*'|'('|')'"
tokensRegex = regEx(tokensExp)
tokensRegex.augmentRegex()
tokenTree = ExpressionTree(tokensRegex.postfix)
tokenTree.showTable()
dfa = DFADirect(tokenTree)
generate_graphviz_files(dfa, "dfa_direct")
lines = []
file = input("Enter input file number: ") 
file = "YALex/slr-" + file + ".yal.run"
with open(file, "r") as f:
    lines = f.readlines()
finds = findAll(lines, tokensExp)
tokens = []
for key, value in finds.items():
    for y in tokenRules.keys():
        for i in range(len(value)):
            if matches(value[i][0], y):
                tokens.append([key, value[i][0], tokenRules[y], value[i][1], value[i][2]])

print("\n\ntokens found\n")
for x in tokens:
    print(x[2], " found in line ", x[0])
    print("Token is: ", x[1])
    print("Starts at: ", x[3])
    print("Ends at: ", x[4], "\n\n")
