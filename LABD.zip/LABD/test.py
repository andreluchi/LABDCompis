from yalex import *


slrOption = input("Archivo SLR:")
filepath = f"YALex/slr-{slrOption}.yal"
yalex = YalProcessor(filepath)
