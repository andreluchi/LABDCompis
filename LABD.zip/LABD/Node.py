class Node:
    def __init__(self, value):
        # Id del nodo
        self.id = None
        # Valor del nodo
        self.value = value
        # Nodos hijos
        self.left =  None
        self.right =None
