# import toNFA 
from regEx import *
from AFN import *
from DFASubsets import *
from ExpressionTree import *
from functions import *

# ask for the regular expression
RegEx = ''
while RegEx != 'exit()':
    RegEx = input("Enter RegEx or use exit(): ")
    if RegEx != 'exit()':
        regex = regEx(RegEx)
        if(regex):
            # /-------------------------------Regex-------------------------------/
            # /-------------------------------Regex-------------------------------/
            # /-------------------------------Regex-------------------------------/
            print("Postfix expression", return_reserved_words(''.join(regex.postfix)))
            tree = ExpressionTree(regex.postfix)
            print("1. simulate NFA\n2. simulate DFA\n3. simulate DFA minimized\n")
            option = input("option: ")
            # /-------------------------------NFA processing-------------------------------/
            # /-------------------------------NFA processing-------------------------------/
            # /-------------------------------NFA processing-------------------------------/
            if option == '1':
                afn = AFN()
                afn.toNFA(tree)
                print(afn)
                afn.showNFA()
                #NFA simulation
                iString = ''
                while iString != 'exit()':
                    iString = input("\nNFA Simulation\nEnter the string to be tested or use exit() to continue the process: ")
                    if iString != 'exit()':
                        result = afn.simulate_afn(iString)
                        print(f"'{return_reserved_words(iString)}' {'matches the RegEx!!' if result else 'does not match the RegEx :('}")
                    else:
                        print('\n\n')
                        break
            # /-------------------------------NFA to DFA-------------------------------/
            # /-------------------------------NFA to DFA-------------------------------/
            # /-------------------------------NFA to DFA-------------------------------/
            elif option == '2':
                afn = AFN()
                afn.toNFA(tree)
                dfa = DFASubsets(afn)
                # dfa.printDFA()
                # dfa.showDFA()
                #DFA simulation
                iString = ''
                while iString != 'exit()':
                    iString = input("\nDFA (not minimized) Simulation \nEnter the string to be tested or use exit() to continue: ")
                    if iString != 'exit()':
                        result = dfa.simulate_dfa(iString)
                        print(f"'{return_reserved_words(iString)}' {'matches the RegEx!!' if result else 'does not match the RegEx :('}")
                    else:
                        print('\n\n')
                        break

            # /-------------------------------NFA to DFA Minimized-------------------------------/
            # /-------------------------------NFA to DFA Minimized-------------------------------/
            # /-------------------------------NFA to DFA Minimized-------------------------------/
            elif option == '3':
                afn = AFN()
                afn.toNFA(tree)
                dfa2 = DFASubsets(afn)
                dfa2.minimize()
                dfa2.printDFA()
                dfa2.showDFA()
                #DFA simulation
                iString = ''
                while iString != 'exit()':
                    iString = input("\nDFA (minimized) Simulation \nEnter the string to be tested or use exit() to parse another RegEx: ")
                    if iString != 'exit()':
                        result = dfa2.simulate_dfa(iString)
                        print(f"'{return_reserved_words(iString)}' {'matches the RegEx!!' if result else 'does not match the RegEx :('}")
                    else:
                        print('\n\n')
                        break

    else:
        print('\n\nFIN\n\n')
