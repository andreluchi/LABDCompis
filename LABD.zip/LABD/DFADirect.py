from tokens import *
from functions import *
from ExpressionTree import ExpressionTree
import graphviz 

class DFADirect:
    def __init__(self, tree: ExpressionTree):
        self.tree =tree
        self.nullable = self.tree.nullable
        self.firstpos = self.tree.firstpos
        self.lastpos = self.tree.lastpos
        self.nextpos = self.tree.nextpos
        self.nodes = self.tree.nodes
        self.symbols = self.tree.symbols
        self.states = []
        self.transition_table = {}
        self.final_states = set()
        self.build_dfa()

    def closure(self, positions):
        result = set(positions)
        for pos in positions:
            if self.nodes[pos] == epsilon:
                result |= self.closure(self.nextpos[pos])
        return result

    def build_dfa(self):
        initial_state = frozenset(self.closure(self.firstpos[self.tree.tree.id]))
        unmarked_states = [initial_state]
        self.states.append(initial_state)
        self.transition_table[initial_state] = {}
        while unmarked_states:
            current_state = unmarked_states.pop()
            for symbol in self.symbols:
                next_positions = set()
                for pos in current_state:
                    if self.nodes[pos] == symbol:
                        next_positions |= set(self.nextpos[pos])  # Convert list to set before union operation
                next_positions_closure = frozenset(self.closure(next_positions))
                if not next_positions_closure:
                    continue
                if next_positions_closure not in self.states:
                    self.states.append(next_positions_closure)
                    unmarked_states.append(next_positions_closure)
                    self.transition_table[next_positions_closure] = {}
                self.transition_table[current_state][symbol] = next_positions_closure
        hash_position = self.tree.tree.right.id
        for state in self.states:
            if hash_position in state:
                self.final_states.add(state)

    def simulate(self, input_string):
        input_string = replace_reserved_words(input_string)
        current_state = self.states[0]
        for symbol in input_string:
            if symbol not in self.symbols:
                return False
            next_state = self.transition_table[current_state].get(symbol)
            if not next_state:
                return False
            current_state = next_state
        return current_state in self.final_states

    def scanner(self, input_string):
        input_string = replace_reserved_words(input_string)
        idx = 0
        results = []  # List to store all the matching substrings with their positions
        while idx < len(input_string):
            current_state = self.states[0]
            temp_idx = idx
            success = False
            matched_string = ""
            while temp_idx < len(input_string):
                symbol = input_string[temp_idx]
                if symbol not in self.symbols:
                    temp_idx += 1
                    continue
                next_state = self.transition_table[current_state].get(symbol)
                if not next_state:
                    break
                current_state = next_state
                temp_idx += 1
                if current_state in self.final_states:
                    success = True
                    matched_string = input_string[idx:temp_idx]
            if success:
                string = return_reserved_words(matched_string)
                results.append((string, idx, temp_idx - 1))  # Append the match and its positions to the results list
                idx = temp_idx  # Update the index to continue scanning from the next character
            else:
                idx += 1
        return results

    def print_dfa(self):
        print("States:")
        for i, state in enumerate(self.states):
            print(f"State {i}: {state}")
        print("\nFinal States:")
        for state in self.final_states:
            print(state)
        print("\nTransition Table:")
        for state, transitions in self.transition_table.items():
            for symbol, next_state in transitions.items():
                print(f"{state} -- {symbol} --> {next_state}")

def generate_graphviz_files(dfa: DFADirect, output_filename: str = 'DFADirect'):
    dot = graphviz.Digraph(format='pdf', engine='dot')
    dot.graph_attr['rankdir'] = 'LR'
    dot.node_attr.update(shape='circle', fixedsize='true', width='1', height='1')

    start_state = dfa.states[0]
    dot.node(str(dfa.states.index(start_state)), label='', shape='none', width='0', height='0')
    dot.edge('', str(dfa.states.index(start_state)), label='', arrowhead='none')
    for final_state in dfa.final_states:
        dot.node(str(dfa.states.index(final_state)), peripheries='2')
    for state, transitions in dfa.transition_table.items():
        state_idx = dfa.states.index(state)
        for symbol, next_state in transitions.items():
            next_state_idx = dfa.states.index(next_state)
            dot.edge(str(state_idx), str(next_state_idx), label=symbol)
    dot.render(f'Graphs/{output_filename}', view=True)