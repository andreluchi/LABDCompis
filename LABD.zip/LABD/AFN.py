import pydot
import webbrowser
from tokens import *
from regEx import regEx
from Node import Node
from functions import *

class AFN:
    def __init__(self, tree=None):
        # Componentes del AFN
        self.states = None
        self.symbols = None
        self.transitions = {}
        self.initial = None
        self.final = None
        self.stack = []
        self.tree = tree
        if tree:
            self.toNFA(self.tree)

    def __str__(self):
        return (('-' * 100) +
                '\nAFN:\n' +
                ('-' * 100) +
                '\nstates: {}\nsymbols: {}\ntransitions: {}\ninitial: {}\nfinal: {}\n' +
                ('-' * 100)
                ).format(self.states, self.symbols, self.transitions, self.initial, self.final)

    #/-------------------------------Funciones para generar el AFN-------------------------------/
    #/-------------------------------Funciones para generar el AFN-------------------------------/
    #/-------------------------------Funciones para generar el AFN-------------------------------/
    def processTokens(self, symbol, i):
        self.transitions[(i, i+1)] = symbol
        push(self.stack, i)
        return i + 2
    def processOr(self, i):
        second_temp_index = pop(self.stack)
        first_temp_index = last(self.stack)
        keys = list(self.transitions)
        keys.sort(reverse=True)
        for key in keys:
            if key[0] >= first_temp_index:
                self.transitions[key[0] + 1, key[1] +
                                 1] = self.transitions.pop(key)
        self.transitions[(first_temp_index,
                          first_temp_index + 1)] = epsilon
        self.transitions[(first_temp_index,
                          second_temp_index + 1)] = epsilon
        self.transitions[(second_temp_index, i + 1)] = epsilon
        self.transitions[(i, i + 1)] = epsilon
        return i + 2
    # Procesa un nodo dot .
    def concatOP(self, i):
        temp_index = pop(self.stack)
        keys = list(self.transitions)
        keys.sort()
        for key in keys:
            if key[0] >= temp_index:
                self.transitions[key[0] - 1, key[1] -
                                 1] = self.transitions.pop(key)
        return i - 1
    # Procesa un nodo kleene *
    def processKleene(self, i):
        temp_index = last(self.stack)
        keys = list(self.transitions)
        keys.sort(reverse=True)
        for key in keys:
            if key[0] >= temp_index:
                self.transitions[key[0] + 1, key[1] +
                                 1] = self.transitions.pop(key)
        self.transitions[(temp_index, temp_index + 1)] = epsilon
        self.transitions[(temp_index, i + 1)] = epsilon
        self.transitions[(i, temp_index + 1)] = epsilon
        self.transitions[(i, i + 1)] = epsilon
        return i + 2
    def processOptional(self, i):
        return self.processOr(self.processTokens(epsilon, i))

    #/-------------------------------Generar el AFN-------------------------------/
    #/-------------------------------Generar el AFN-------------------------------/
    #/-------------------------------Generar el AFN-------------------------------/
    def genNFA(self, root: Node, i=0):
        if root:
            i = self.genNFA(root.left, i)
            i = self.genNFA(root.right, i)
            # Simbolos (a, b, c, d, etc)
            if root.value in symbols:
                return self.processTokens(root.value, i)
            # OR |
            elif root.value == alternative:
                return self.processOr(i)
            # Concatenation .
            elif root.value == dot:
                return self.concatOP(i)
            # Kleene *
            elif root.value == kleene:
                i = self.processKleene(i)  # Update this line
            # Optional ?
            elif root.value == optional:
                return self.processOptional(i)
        return i

    def toNFA(self, expression_tree: regEx):
        '''Genera la AFN a partir de un arbol de una expresión'''
        self.genNFA(expression_tree.tree)
        keys = list(self.transitions)
        keys.sort()
        for key in keys:
            self.transitions[key] = self.transitions.pop(key)
        states = list(dict.fromkeys([item for t in keys for item in t]))
        states.sort()
        newTransitions = {}
        for (i, f), t in self.transitions.items():
            if(i, t) not in newTransitions:
                newTransitions[(i, t)] = [f]
            else:
                newTransitions[(i, t)].append(f)
        self.states = states
        self.symbols = list(dict.fromkeys(self.transitions.values()))
        self.transitions = newTransitions
        self.initial = states[0]
        self.final = states[len(states) - 1]
        expression_tree.symbols = self.symbols

    def showNFA(self):
        with open('Graphs/AFN.dot', 'w', encoding='utf-8') as file:
            keys = list(self.transitions)
            file.write('digraph{\n')
            file.write('rankdir=LR\n')
            for state in self.states:
                if state == self.initial:
                    file.write('{} [root=true]\n'.format(state))
                    file.write('fake [style=invisible]\n')
                    file.write('fake -> {} [style=bold]\n'.format(state))
                elif state == self.final:
                    file.write('{} [shape=doublecircle]\n'.format(state))
                else:
                    file.write('{}\n'.format(state))
            for key in keys:
                for t in self.transitions[key]:
                    transition_label = key[1]
                    if transition_label == kleene:
                        transition_label = epsilon
                    file.write('{} -> {} [ label="{}" ]\n'.format(key[0], t, transition_label.replace('"', r'\"')))
            file.write('}\n')
        (graph,) = pydot.graph_from_dot_file('Graphs/AFN.dot')
        graph.write_png('Graphs/AFN.png')

    # /-------------------------------Simulacion del AFN-------------------------------/
    # /-------------------------------Simulacion del AFN-------------------------------/
    # /-------------------------------Simulacion del AFN-------------------------------/
    def epsilon_closure(self, states):
        closure = set(states)
        stack = list(states)
        while stack:
            state = stack.pop()
            if (state, epsilon) in self.transitions:
                for epsilon_state in self.transitions[(state, epsilon)]:
                    if epsilon_state not in closure:
                        closure.add(epsilon_state)
                        stack.append(epsilon_state)
        return closure


    def simulate_afn(self, word):
        word = replace_reserved_words(word)
        current_states = self.epsilon_closure([self.initial])
        for symbol in word:
            next_states = set()
            for state in current_states:
                if (state, symbol) in self.transitions:
                    next_states |= set(self.transitions[(state, symbol)])
            current_states = self.epsilon_closure(next_states)
        return self.final in current_states
